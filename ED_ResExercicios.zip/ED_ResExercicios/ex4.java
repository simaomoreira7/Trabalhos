public class ex4 {
    
}
